/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9170833333333334, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.92, 500, 1500, "webstaurantstore - 011 - /outlet.html?category=8159"], "isController": false}, {"data": [1.0, 500, 1500, "webstaurantstore - 014 - /outlet.html?category=48565"], "isController": false}, {"data": [0.4866666666666667, 500, 1500, "T00_Outlet Home"], "isController": true}, {"data": [0.9466666666666667, 500, 1500, "webstaurantstore - 002 - /outlet.html?category=50415"], "isController": false}, {"data": [0.94, 500, 1500, "T03_Commercial Ovens"], "isController": true}, {"data": [0.96, 500, 1500, "T05_Merchandising and Display Refrigeration"], "isController": true}, {"data": [0.9733333333333334, 500, 1500, "T07_Bar Refrigeration"], "isController": true}, {"data": [0.92, 500, 1500, "T11_Hotel Supplies"], "isController": true}, {"data": [1.0, 500, 1500, "webstaurantstore - 013 - /outlet.html?category=56099"], "isController": false}, {"data": [0.9133333333333333, 500, 1500, "T04_Beverage Equipment"], "isController": true}, {"data": [0.98, 500, 1500, "webstaurantstore - 015 - /outlet.html?category=48573"], "isController": false}, {"data": [0.96, 500, 1500, "webstaurantstore - 005 - /outlet.html?category=13387"], "isController": false}, {"data": [1.0, 500, 1500, "T13_Janitorial Equipment"], "isController": true}, {"data": [0.9866666666666667, 500, 1500, "T09_Storage & Workspace"], "isController": true}, {"data": [0.62, 500, 1500, "webstaurantstore - 001 - /outlet.html?category=14177"], "isController": false}, {"data": [1.0, 500, 1500, "T10_Facility & Maintenance"], "isController": true}, {"data": [1.0, 500, 1500, "T14_Restroom Supplies"], "isController": true}, {"data": [0.9466666666666667, 500, 1500, "T02_Commercial Ice Equipment and Supplies"], "isController": true}, {"data": [0.9933333333333333, 500, 1500, "T06_Reach-In Refrigerators and Freezers"], "isController": true}, {"data": [0.9733333333333334, 500, 1500, "webstaurantstore - 007 - /outlet.html?category=47651"], "isController": false}, {"data": [0.62, 500, 1500, "T01_Cooking Equipment"], "isController": true}, {"data": [0.9933333333333333, 500, 1500, "webstaurantstore - 006 - /outlet.html?category=13421"], "isController": false}, {"data": [0.9933333333333333, 500, 1500, "webstaurantstore - 008 - /outlet.html?category=26885"], "isController": false}, {"data": [0.98, 500, 1500, "T15_Trash Cans and Recycling Bins"], "isController": true}, {"data": [0.9133333333333333, 500, 1500, "webstaurantstore - 004 - /outlet.html?category=13949"], "isController": false}, {"data": [0.94, 500, 1500, "webstaurantstore - 003 - /outlet.html?category=42715"], "isController": false}, {"data": [0.9866666666666667, 500, 1500, "webstaurantstore - 009 - /outlet.html?category=65103"], "isController": false}, {"data": [0.96, 500, 1500, "webstaurantstore - 012 - /outlet.html?category=51953"], "isController": false}, {"data": [0.9933333333333333, 500, 1500, "T08_Undercounter Refrigerators"], "isController": true}, {"data": [0.96, 500, 1500, "T12_Office Products"], "isController": true}, {"data": [1.0, 500, 1500, "webstaurantstore - 010 - /outlet.html?category=65513"], "isController": false}, {"data": [0.4866666666666667, 500, 1500, "webstaurantstore - 000 - /outlet.html (outlet)"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1200, 0, 0.0, 385.5525000000001, 193, 4773, 335.5, 578.0, 722.9000000000001, 957.4800000000005, 1.336323728877733, 71.30859187949478, 1.3041880142062348], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["webstaurantstore - 011 - /outlet.html?category=8159", 75, 0, 0.0, 446.03999999999996, 328, 835, 426.0, 599.2, 617.4, 835.0, 0.08397762835980495, 5.636918481166617, 0.07995916762774397], "isController": false}, {"data": ["webstaurantstore - 014 - /outlet.html?category=48565", 75, 0, 0.0, 253.0933333333333, 202, 423, 248.0, 308.20000000000005, 376.20000000000005, 423.0, 0.08404472524098425, 3.102878727943863, 0.08010512874531311], "isController": false}, {"data": ["T00_Outlet Home", 75, 0, 0.0, 825.4133333333335, 622, 4773, 747.0, 902.0, 1059.6000000000008, 4773.0, 0.08393993929463589, 9.063983288677285, 0.060249858771052135], "isController": true}, {"data": ["webstaurantstore - 002 - /outlet.html?category=50415", 75, 0, 0.0, 370.04, 279, 603, 344.0, 503.80000000000007, 549.2, 603.0, 0.08388773807340065, 4.226409518475995, 0.0862634650305575], "isController": false}, {"data": ["T03_Commercial Ovens", 75, 0, 0.0, 390.90666666666675, 291, 859, 374.0, 513.0, 541.0, 859.0, 0.08394651599572879, 4.831137298304504, 0.08632390756201408], "isController": true}, {"data": ["T05_Merchandising and Display Refrigeration", 75, 0, 0.0, 400.40000000000015, 252, 2246, 354.0, 488.80000000000007, 564.6000000000008, 2246.0, 0.08407722998037077, 4.280124363535369, 0.08645832340754923], "isController": true}, {"data": ["T07_Bar Refrigeration", 75, 0, 0.0, 364.9866666666666, 259, 958, 338.0, 479.0, 522.8000000000001, 958.0, 0.08397349124828274, 4.090565252860976, 0.08635164676215012], "isController": true}, {"data": ["T11_Hotel Supplies", 75, 0, 0.0, 446.03999999999996, 328, 835, 426.0, 599.2, 617.4, 835.0, 0.08397762835980495, 5.636918481166617, 0.07995916762774397], "isController": true}, {"data": ["webstaurantstore - 013 - /outlet.html?category=56099", 75, 0, 0.0, 258.5733333333333, 198, 420, 253.0, 326.4000000000001, 375.6, 420.0, 0.08398176587899235, 3.2039054617961344, 0.08004512060341458], "isController": false}, {"data": ["T04_Beverage Equipment", 75, 0, 0.0, 407.82666666666677, 291, 2243, 368.0, 537.4, 568.2, 2243.0, 0.08404594960156617, 4.485954748680198, 0.08642615715864177], "isController": true}, {"data": ["webstaurantstore - 015 - /outlet.html?category=48573", 75, 0, 0.0, 286.5333333333334, 193, 2129, 257.0, 369.8, 395.80000000000007, 2129.0, 0.08403672068547073, 3.1026630834109272, 0.08009749940333928], "isController": false}, {"data": ["webstaurantstore - 005 - /outlet.html?category=13387", 75, 0, 0.0, 400.40000000000015, 252, 2246, 354.0, 488.80000000000007, 564.6000000000008, 2246.0, 0.08407713572740175, 4.280119565394075, 0.08645822648530668], "isController": false}, {"data": ["T13_Janitorial Equipment", 75, 0, 0.0, 258.5733333333333, 198, 420, 253.0, 326.4000000000001, 375.6, 420.0, 0.08398176587899235, 3.2039054617961344, 0.08004512060341458], "isController": true}, {"data": ["T09_Storage & Workspace", 75, 0, 0.0, 304.1333333333332, 215, 567, 295.0, 436.4, 458.4, 567.0, 0.08404500778256772, 3.614811897817519, 0.08010539804275986], "isController": true}, {"data": ["webstaurantstore - 001 - /outlet.html?category=14177", 75, 0, 0.0, 564.3200000000002, 441, 1630, 533.0, 691.0000000000001, 731.2, 1630.0, 0.08402551686896276, 6.805658773706399, 0.08640514576466582], "isController": false}, {"data": ["T10_Facility & Maintenance", 75, 0, 0.0, 308.9066666666668, 249, 480, 306.0, 356.4000000000001, 452.40000000000003, 480.0, 0.08399361648514714, 3.7404522881261024, 0.08005641571240586], "isController": true}, {"data": ["T14_Restroom Supplies", 75, 0, 0.0, 253.0933333333333, 202, 423, 248.0, 308.20000000000005, 376.20000000000005, 423.0, 0.08404472524098425, 3.102878727943863, 0.08010512874531311], "isController": true}, {"data": ["T02_Commercial Ice Equipment and Supplies", 75, 0, 0.0, 370.04, 279, 603, 344.0, 503.80000000000007, 549.2, 603.0, 0.08388783190220692, 4.226414245733745, 0.08626356151662488], "isController": true}, {"data": ["T06_Reach-In Refrigerators and Freezers", 75, 0, 0.0, 336.3066666666667, 256, 739, 320.0, 471.6, 485.8, 739.0, 0.08399023025641657, 3.8534892621290293, 0.08636885982422525], "isController": true}, {"data": ["webstaurantstore - 007 - /outlet.html?category=47651", 75, 0, 0.0, 364.9866666666666, 259, 958, 338.0, 479.0, 522.8000000000001, 958.0, 0.08397358526901778, 4.090569832853378, 0.08635174344558176], "isController": false}, {"data": ["T01_Cooking Equipment", 75, 0, 0.0, 564.3200000000002, 441, 1630, 533.0, 691.0000000000001, 731.2, 1630.0, 0.08402551686896276, 6.805658773706399, 0.08640514576466582], "isController": true}, {"data": ["webstaurantstore - 006 - /outlet.html?category=13421", 75, 0, 0.0, 336.3066666666667, 256, 739, 320.0, 471.6, 485.8, 739.0, 0.08399023025641657, 3.8534892621290293, 0.08636885982422525], "isController": false}, {"data": ["webstaurantstore - 008 - /outlet.html?category=26885", 75, 0, 0.0, 280.64000000000004, 218, 502, 271.0, 384.40000000000003, 399.0, 502.0, 0.08401356314963487, 3.543631927688406, 0.08639285351227102], "isController": false}, {"data": ["T15_Trash Cans and Recycling Bins", 75, 0, 0.0, 286.5333333333334, 193, 2129, 257.0, 369.8, 395.80000000000007, 2129.0, 0.08403672068547073, 3.1026630834109272, 0.08009749940333928], "isController": true}, {"data": ["webstaurantstore - 004 - /outlet.html?category=13949", 75, 0, 0.0, 407.82666666666677, 291, 2243, 368.0, 537.4, 568.2, 2243.0, 0.08404594960156617, 4.485954748680198, 0.08642615715864177], "isController": false}, {"data": ["webstaurantstore - 003 - /outlet.html?category=42715", 75, 0, 0.0, 390.90666666666675, 291, 859, 374.0, 513.0, 541.0, 859.0, 0.08394651599572879, 4.831137298304504, 0.08632390756201408], "isController": false}, {"data": ["webstaurantstore - 009 - /outlet.html?category=65103", 75, 0, 0.0, 304.1333333333332, 215, 567, 295.0, 436.4, 458.4, 567.0, 0.08404491360182882, 3.614807847063471, 0.08010530827674309], "isController": false}, {"data": ["webstaurantstore - 012 - /outlet.html?category=51953", 75, 0, 0.0, 370.71999999999997, 268, 611, 343.0, 498.4, 523.2, 611.0, 0.08404679725671255, 4.13245298106986, 0.08010710363530414], "isController": false}, {"data": ["T08_Undercounter Refrigerators", 75, 0, 0.0, 280.64000000000004, 218, 502, 271.0, 384.40000000000003, 399.0, 502.0, 0.0840136572601242, 3.5436358972014492, 0.08639295028799882], "isController": true}, {"data": ["T12_Office Products", 75, 0, 0.0, 370.71999999999997, 268, 611, 343.0, 498.4, 523.2, 611.0, 0.08404679725671255, 4.13245298106986, 0.08010710363530414], "isController": true}, {"data": ["webstaurantstore - 010 - /outlet.html?category=65513", 75, 0, 0.0, 308.9066666666668, 249, 480, 306.0, 356.4000000000001, 452.40000000000003, 480.0, 0.08399361648514714, 3.7404522881261024, 0.08005641571240586], "isController": false}, {"data": ["webstaurantstore - 000 - /outlet.html (outlet)", 75, 0, 0.0, 825.4133333333335, 622, 4773, 747.0, 902.0, 1059.6000000000008, 4773.0, 0.08393993929463589, 9.063983288677285, 0.060249858771052135], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1200, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
